<?php

class WpakConfig {
    const uncatcrea_website_url = 'https://uncategorized-creations.com/';
    const support_url = 'https://uncategorized-creations.com/contact-us/';
    const my_account_url = 'https://uncategorized-creations.com/my-account/';
    const checkout_url = 'https://uncategorized-creations.com/checkout/';
	const license_renewal_url = 'https://uncategorized-creations.com/pro-support-license-renewal/';
    const pwa_icons_tutorial = 'https://uncategorized-creations.com/4217/add-icons-progressive-web-app/';
}

